import 'package:flutter/foundation.dart';
import '../models/question.dart';
import '../data/quiz_questions.dart';

class QuizProvider with ChangeNotifier {
  // 1. المتغيرات الخاصة بحالة الكويز
  int _currentQuestionIndex = 0;
  final Map<int, int> _selectedAnswers =
      {}; // تخزين رقم السؤال والإجابة التي اختارها المستخدم

  // 2. Getters عشان الشاشات تعرف تقرأ البيانات
  List<Question> get questions => sampleQuestions;
  int get currentQuestionIndex => _currentQuestionIndex;
  Question get currentQuestion => sampleQuestions[_currentQuestionIndex];
  bool get isLastQuestion =>
      _currentQuestionIndex == sampleQuestions.length - 1;
  Map<int, int> get selectedAnswers => _selectedAnswers;

  // الدرجة بتتحسب من الإجابات المسجلة، فمستحيل سؤال يتحسب مرتين
  int get score {
    var correct = 0;
    _selectedAnswers.forEach((questionIndex, answerIndex) {
      if (sampleQuestions[questionIndex].correctAnswerIndex == answerIndex) {
        correct++;
      }
    });
    return correct;
  }

  // بيانات إضافية مفيدة لـ Result Screen
  int get totalQuestions => sampleQuestions.length;
  int get correctAnswers => score;
  int get wrongAnswers => _selectedAnswers.length - score;
  double get percentage =>
      totalQuestions == 0 ? 0 : score / totalQuestions * 100;

  // حالة السؤال الحالي
  bool get isCurrentAnswered =>
      _selectedAnswers.containsKey(_currentQuestionIndex);
  int? get selectedAnswerForCurrent => _selectedAnswers[_currentQuestionIndex];

  // 3. اختيار إجابة للسؤال الحالي (مرة واحدة فقط لكل سؤال)
  void selectAnswer(int answerIndex) {
    if (isCurrentAnswered) return;
    if (answerIndex < 0 || answerIndex >= currentQuestion.options.length) {
      return;
    }
    _selectedAnswers[_currentQuestionIndex] = answerIndex;
    notifyListeners(); // إعلام الشاشات لتحديث الواجهة
  }

  // 4. الانتقال للسؤال التالي (الدرجة محسوبة تلقائيًا من الإجابات)
  void nextQuestion() {
    if (!isLastQuestion) {
      _currentQuestionIndex++;
      notifyListeners();
    }
  }

  // 5. إعادة بدء الكويز من جديد
  void resetQuiz() {
    _currentQuestionIndex = 0;
    _selectedAnswers.clear();
    notifyListeners();
  }
}
