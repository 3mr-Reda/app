import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../models/quiz_category.dart';
import '../providers/quiz_provider.dart';
import '../services/app_settings.dart';

class QuizScreen extends StatefulWidget {
  final QuizCategory category;

  /// بيتنادى لما المستخدم يخلص آخر سؤال. النتيجة موجودة في QuizProvider
  /// (score, totalQuestions, wrongAnswers, percentage, selectedAnswers, questions).
  /// لو اتساب null بيظهر ملخص مؤقت لحد ما Result Screen تتوصل.
  final void Function(BuildContext context)? onFinish;

  const QuizScreen({
    super.key,
    required this.category,
    this.onFinish,
  });

  @override
  State<QuizScreen> createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> {
  bool _ready = false;
  bool _finishing = false;

  @override
  void initState() {
    super.initState();
    // بنبدأ جلسة جديدة بعد أول frame عشان منعملش notify أثناء الـ build
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      context.read<QuizProvider>().resetQuiz();
      setState(() => _ready = true);
    });
  }

  void _onNext(QuizProvider quiz) {
    if (_finishing) return; // يمنع الضغط المزدوج على Finish
    AppSettings.instance.triggerHaptic();
    if (quiz.isLastQuestion) {
      _finishing = true;
      _handleFinish(quiz);
    } else {
      quiz.nextQuestion();
    }
  }

  void _handleFinish(QuizProvider quiz) {
    if (widget.onFinish != null) {
      widget.onFinish!(context);
      return;
    }
    // ملخص مؤقت لحد ما Result Screen تتوصل عن طريق onFinish
    showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        title: const Text('Quiz finished'),
        content: Text(
          'Score: ${quiz.score}/${quiz.totalQuestions} '
          '(${quiz.percentage.round()}%)',
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(ctx);
              Navigator.of(context).pop();
            },
            child: const Text('Done'),
          ),
        ],
      ),
    );
  }

  Future<void> _confirmExit() async {
    final navigator = Navigator.of(context);
    final quiz = context.read<QuizProvider>();
    final leave = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Quit quiz?'),
        content: const Text('Your progress will be lost.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Stay'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Quit'),
          ),
        ],
      ),
    );
    if (leave == true) {
      quiz.resetQuiz();
      navigator.pop();
    }
  }

  _AnswerState _stateFor(QuizProvider quiz, int index) {
    final selected = quiz.selectedAnswerForCurrent;
    if (selected == null) return _AnswerState.idle;
    final correctIndex = quiz.currentQuestion.correctAnswerIndex;
    if (index == selected) {
      return index == correctIndex ? _AnswerState.correct : _AnswerState.wrong;
    }
    if (index == correctIndex) return _AnswerState.revealed;
    return _AnswerState.disabled;
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final accent = widget.category.color;
    final titleColor = isDark ? Colors.white : const Color(0xFF0F172A);

    if (!_ready) {
      return Scaffold(
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        body: const Center(child: CircularProgressIndicator()),
      );
    }

    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) _confirmExit();
      },
      child: Scaffold(
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        body: SafeArea(
          child: Consumer<QuizProvider>(
            builder: (context, quiz, _) {
              final question = quiz.currentQuestion;
              final answered = quiz.isCurrentAnswered;

              return Column(
                children: [
                  // Top bar
                  Padding(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    child: Row(
                      children: [
                        IconButton(
                          icon: Icon(Icons.close_rounded,
                              color: titleColor, size: 24),
                          onPressed: () {
                            AppSettings.instance.triggerHaptic();
                            Navigator.maybePop(context);
                          },
                        ),
                        Expanded(
                          child: Text(
                            widget.category.displayTitle,
                            textAlign: TextAlign.center,
                            style: GoogleFonts.plusJakartaSans(
                              fontSize: 18,
                              fontWeight: FontWeight.w700,
                              color: titleColor,
                            ),
                          ),
                        ),
                        const SizedBox(width: 48),
                      ],
                    ),
                  ),

                  // Content
                  Expanded(
                    child: SingleChildScrollView(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _ProgressHeader(
                            current: quiz.currentQuestionIndex + 1,
                            total: quiz.totalQuestions,
                            color: accent,
                          ),
                          const SizedBox(height: 24),
                          Text(
                            question.questionText,
                            style: GoogleFonts.plusJakartaSans(
                              fontSize: 22,
                              fontWeight: FontWeight.w800,
                              height: 1.3,
                              color: titleColor,
                            ),
                          ),
                          const SizedBox(height: 24),
                          for (var i = 0; i < question.options.length; i++)
                            Padding(
                              padding: const EdgeInsets.only(bottom: 12),
                              child: _AnswerTile(
                                label: String.fromCharCode(65 + i),
                                text: question.options[i],
                                state: _stateFor(quiz, i),
                                onTap: answered
                                    ? null
                                    : () {
                                        AppSettings.instance.triggerHaptic();
                                        quiz.selectAnswer(i);
                                      },
                              ),
                            ),
                          const SizedBox(height: 8),
                        ],
                      ),
                    ),
                  ),

                  // Next / Finish button
                  Padding(
                    padding: const EdgeInsets.fromLTRB(20, 8, 20, 16),
                    child: SizedBox(
                      width: double.infinity,
                      height: 54,
                      child: ElevatedButton(
                        onPressed: answered ? () => _onNext(quiz) : null,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: accent,
                          disabledBackgroundColor:
                              accent.withValues(alpha: 0.35),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16),
                          ),
                          elevation: 0,
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              quiz.isLastQuestion ? 'Finish' : 'Next',
                              style: GoogleFonts.plusJakartaSans(
                                fontSize: 16,
                                fontWeight: FontWeight.w700,
                                color: Colors.white,
                              ),
                            ),
                            const SizedBox(width: 8),
                            Icon(
                              quiz.isLastQuestion
                                  ? Icons.flag_rounded
                                  : Icons.arrow_forward_rounded,
                              color: Colors.white,
                              size: 20,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              );
            },
          ),
        ),
      ),
    );
  }
}

// ===================== Widgets خاصة بالشاشة =====================

/// رقم السؤال + شريط التقدم
class _ProgressHeader extends StatelessWidget {
  final int current;
  final int total;
  final Color color;

  const _ProgressHeader({
    required this.current,
    required this.total,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final progress = total == 0 ? 0.0 : (current / total).clamp(0.0, 1.0);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Question $current of $total',
              style: GoogleFonts.plusJakartaSans(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: isDark ? Colors.white70 : const Color(0xFF64748B),
              ),
            ),
            Text(
              '${(progress * 100).round()}%',
              style: GoogleFonts.plusJakartaSans(
                fontSize: 14,
                fontWeight: FontWeight.w700,
                color: color,
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: TweenAnimationBuilder<double>(
            tween: Tween<double>(begin: 0, end: progress),
            duration: const Duration(milliseconds: 350),
            curve: Curves.easeOut,
            builder: (context, value, _) => LinearProgressIndicator(
              value: value,
              minHeight: 8,
              color: color,
              backgroundColor:
                  isDark ? const Color(0xFF334155) : const Color(0xFFE2E8F0),
            ),
          ),
        ),
      ],
    );
  }
}

enum _AnswerState { idle, correct, wrong, revealed, disabled }

/// اختيار واحد من إجابات السؤال
class _AnswerTile extends StatelessWidget {
  final String label;
  final String text;
  final _AnswerState state;
  final VoidCallback? onTap;

  const _AnswerTile({
    required this.label,
    required this.text,
    required this.state,
    required this.onTap,
  });

  static const Color _green = Color(0xFF22C55E);
  static const Color _red = Color(0xFFEF4444);

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final textColor = isDark ? Colors.white : const Color(0xFF0F172A);

    var borderColor = isDark ? const Color(0xFF334155) : const Color(0xFFE2E8F0);
    var background = Theme.of(context).colorScheme.surface;
    var badgeColor = isDark ? const Color(0xFF334155) : const Color(0xFFF1F5F9);
    var badgeTextColor = isDark ? Colors.white70 : const Color(0xFF64748B);
    Widget? trailing;

    switch (state) {
      case _AnswerState.idle:
      case _AnswerState.disabled:
        break;
      case _AnswerState.correct:
      case _AnswerState.revealed:
        borderColor = _green;
        background = _green.withValues(alpha: isDark ? 0.18 : 0.10);
        badgeColor = _green;
        badgeTextColor = Colors.white;
        trailing = const Icon(Icons.check_circle_rounded, color: _green);
        break;
      case _AnswerState.wrong:
        borderColor = _red;
        background = _red.withValues(alpha: isDark ? 0.18 : 0.10);
        badgeColor = _red;
        badgeTextColor = Colors.white;
        trailing = const Icon(Icons.cancel_rounded, color: _red);
        break;
    }

    return Semantics(
      button: true,
      enabled: onTap != null,
      label: 'Option $label: $text',
      child: Opacity(
        opacity: state == _AnswerState.disabled ? 0.6 : 1,
        child: Material(
          color: background,
          borderRadius: BorderRadius.circular(16),
          child: InkWell(
            borderRadius: BorderRadius.circular(16),
            onTap: onTap,
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: borderColor, width: 1.6),
              ),
              child: Row(
                children: [
                  Container(
                    width: 34,
                    height: 34,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: badgeColor,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Text(
                      label,
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                        color: badgeTextColor,
                      ),
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Text(
                      text,
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 15,
                        fontWeight: FontWeight.w600,
                        color: textColor,
                      ),
                    ),
                  ),
                  if (trailing != null) ...[
                    const SizedBox(width: 8),
                    trailing,
                  ],
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
